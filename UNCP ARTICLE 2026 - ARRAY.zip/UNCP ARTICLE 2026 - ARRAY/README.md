# UNCP ARTICLE 2026 — Final Files

- `01 Response to Reviewers`: response PDF, highlighted manuscript, and reviewer-action matrix.
- `02 Article`: final manuscript PDF and a ZIP containing the complete LaTeX source plus final PDF.
- `03 Data`: exact repeat-inclusive dataset identified by the latest model audit.
- `04 Code`: one consolidated Google Colab notebook containing all model implementations and saved results.
- `05 Experiment`: experiment evidence grouped by reviewer-question number.

No source working files were moved or deleted; this directory is a curated copy.
